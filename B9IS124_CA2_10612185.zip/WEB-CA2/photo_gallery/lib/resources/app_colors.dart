import 'package:flutter/material.dart';

class AppColors {

  static const Color appThemeColor = Colors.red;
}
