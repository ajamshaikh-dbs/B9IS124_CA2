import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/home_controller.dart';

class SelectedImages extends StatelessWidget {
  SelectedImages({Key? key}) : super(key: key);
  final homeController = Get.put(HomeController());

  @override
  Widget build(BuildContext context) {
    return Obx(
      () {
        if (homeController.imageFileList.isEmpty) {
          return Center(
            child: Text(
              "No images selected yet.",
              style: TextStyle(
                fontSize: 18.0,
              ),
            ),
          );
        }
        return GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, crossAxisSpacing: 4.0, mainAxisSpacing: 4.0),
          itemBuilder: (context, index) {
            return Image.file(
              File(homeController.imageFileList[index].path),
              key: UniqueKey(),
            );
          },
          itemCount: homeController.imageFileList.length,
        );
      },
    );
  }
}
