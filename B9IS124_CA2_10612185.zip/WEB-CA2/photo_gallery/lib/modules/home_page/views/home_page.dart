import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:photo_gallery2/modules/home_page/views/selected_images.dart';

import '../controllers/home_controller.dart';


class HomePage extends StatelessWidget {
  HomePage({Key? key}) : super(key: key);
  final List<IconData> icons = const [Icons.photo_camera, Icons.photo];
  final homeController = Get.put(HomeController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Photo Gallery'),
      ),
      backgroundColor: Colors.white,
      body: SelectedImages(),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 16.0),
            child: FloatingActionButton(
              heroTag: "imagePicker",
              onPressed: homeController.takePhoto,
              tooltip: 'Take a Photo',
              child: const Icon(Icons.camera_alt),
              backgroundColor: Colors.blueGrey,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 16.0),
            child: FloatingActionButton(
              heroTag: 'takePhoto',
              onPressed: homeController.pickMultiplePhotos,
              tooltip: 'Pick Multiple Image from gallery',
              child: const Icon(Icons.photo_library),
              backgroundColor: Colors.blueAccent,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 16.0),
            child: FloatingActionButton(
              heroTag: 'clearSelection',
              onPressed: homeController.clearSelectedList,
              tooltip: 'Clear selection',
              child: const Icon(Icons.delete_forever),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 16.0),
            child: FloatingActionButton(
              backgroundColor: Colors.blue,
              heroTag: 'vibration',
              onPressed: homeController.vibrateWithPauses1,
              tooltip: 'vibration',
              child: const Icon(Icons.vibration),
            ),
          ),
        ],
      ),
    );
  }
}
