import 'package:flutter_vibrate/flutter_vibrate.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

class HomeController extends GetxController {
  Future<bool> isCameraPermissionGranted() async {
    return await Permission.camera.request().isGranted;
  }

  final ImagePicker _picker = ImagePicker();
  RxList<XFile> imageFileList = RxList();
  final Iterable<Duration> pauses = [
    const Duration(milliseconds: 500),
    const Duration(milliseconds: 1000),
    const Duration(milliseconds: 500),
  ];

  void takePhoto() async {
    if (await isCameraPermissionGranted()) {
      final XFile? photo = await _picker.pickImage(source: ImageSource.camera);
      if (photo != null) {
        imageFileList.add(photo);
      }
    } else {
      Get.snackbar(
          'Camera permission required', 'Please allow permission from setting');
    }
  }

  void pickMultiplePhotos() async {
    final List<XFile>? images = await _picker.pickMultiImage();
    if (images?.isNotEmpty == true) {
      imageFileList.addAll(images!);
    }
  }

  void clearSelectedList() {
    imageFileList.clear();
  }

  void vibrateWithPauses1() {
    Vibrate.vibrateWithPauses(pauses);
  }
}
